#!/bin/bash

# =============================================
# MarketMax - Script de Inicialização
# =============================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "  __  __            _        _   __  __            "
echo " |  \/  | __ _ _ __| | _____| |_|  \/  | __ ___  __"
echo " | |\/| |/ _\` | '__| |/ / _ \ __| |\/| |/ _\` \ \/ /"
echo " | |  | | (_| | |  |   <  __/ |_| |  | | (_| |>  < "
echo " |_|  |_|\__,_|_|  |_|\_\___|\__|_|  |_|\__,_/_/\_\\"
echo -e "${NC}"
echo -e "${GREEN}MarketMax - Marketplace Profissional${NC}"
echo -e "Backend: Spring Boot 3 + MySQL | Frontend: HTML + JavaScript (fetch) + Tailwind CSS"
echo -e "O backend serve o frontend estático — uma única aplicação em http://localhost:8080"
echo ""

# Check if Docker is available
if command -v docker &> /dev/null && command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}Iniciando com Docker Compose...${NC}"
    docker-compose up --build -d
    echo ""
    echo -e "${GREEN}✅ Aplicação iniciada!${NC}"
    echo -e "  App:          ${BLUE}http://localhost:8080${NC}"
    echo -e "  Backend API:  ${BLUE}http://localhost:8080/api${NC}"
    echo -e "  Swagger UI:   ${BLUE}http://localhost:8080/swagger-ui.html${NC}"
else
    echo -e "${YELLOW}Docker não encontrado. Iniciando manualmente...${NC}"
    echo ""

    # Start MySQL check
    echo -e "${YELLOW}1. Certifique-se que o MySQL está rodando na porta 3306${NC}"
    echo "   Credenciais: root / marketmax123"
    echo "   Banco de dados: marketmax"
    echo ""

    # Start Backend (também serve o frontend estático em /static)
    echo -e "${YELLOW}2. Iniciando Backend Spring Boot (API + Frontend)...${NC}"
    cd backend
    mvn spring-boot:run &
    BACKEND_PID=$!
    cd ..
    echo -e "   Backend PID: $BACKEND_PID"
    echo ""

    echo -e "${YELLOW}Aguardando backend inicializar (20s)...${NC}"
    sleep 20

    echo -e "${GREEN}✅ Aplicação iniciada!${NC}"
    echo -e "  App:          ${BLUE}http://localhost:8080${NC}"
    echo -e "  Backend API:  ${BLUE}http://localhost:8080/api${NC}"
    echo -e "  Swagger UI:   ${BLUE}http://localhost:8080/swagger-ui.html${NC}"
    echo ""
    echo "Para parar: kill $BACKEND_PID"
fi
