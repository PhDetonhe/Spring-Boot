# MarketMax — Marketplace estilo Mercado Livre

**MarketMax** é uma aplicação de marketplace completa, inspirada no Mercado Livre, desenvolvida com **Java Spring Boot** no backend, **MySQL** como banco de dados e um frontend em **HTML + JavaScript puro (fetch API) + Tailwind CSS**, sem React, sem TypeScript e sem etapa de build.

O backend serve o frontend estático diretamente (`src/main/resources/static`), então a aplicação inteira roda como **um único processo**, em **http://localhost:8080** — sem CORS, sem npm, sem Node.

---

## Tecnologias

| Camada | Tecnologia |
|---|---|
| Backend | Java 21 + Spring Boot 3.2 |
| Banco de Dados | MySQL 8.0 |
| ORM | Spring Data JPA + Hibernate |
| Documentação API | SpringDoc OpenAPI (Swagger UI) |
| Frontend | HTML5 + JavaScript (vanilla, `fetch`) |
| Estilização | Tailwind CSS (via CDN, sem build) |
| Containerização | Docker + Docker Compose |

---

## Funcionalidades

- **Login e cadastro** com senha criptografada (BCrypt) e autenticação via **JWT**
- **Home** com banner, grade de categorias, "Ofertas do dia" (produtos com desconto) e grid geral de produtos
- **Busca** por texto e **filtro por categoria** (`?q=` e `?category=`)
- **Página de produto** com galeria de imagens, preço com desconto, parcelamento, frete grátis, especificações técnicas, dados do vendedor e botão de favoritar
- **Carrinho de compras** com alterar quantidade, remover item, esvaziar carrinho e resumo do pedido (por usuário logado)
- **Checkout** que gera um pedido e uma notificação no backend
- **Favoritos** (♥ nos cards de produto e na página de produto), por usuário
- **Minha conta**: editar perfil, trocar senha e ver histórico de pedidos
- **Painel administrativo** (`/admin.html`, requer papel ADMIN): CRUD completo de categorias, produtos e usuários, gestão de status de pedidos e dashboard de vendas com gráficos (receita por dia, status dos pedidos, produtos mais vendidos, usuários que mais compraram)
- Layout **100% responsivo** (mobile, tablet, desktop)

### Contas de demonstração (criadas automaticamente pelo `DataInitializer`)

| Papel | E-mail | Senha |
|---|---|---|
| Comprador | `ricardo@marketmax.com` | `demo123` |
| Administrador | `admin@marketmax.com` | `admin123` |

> Como o banco agora tem novas colunas/tabelas (usuários com e-mail/senha/papel, categorias, etc.), se você já tinha um banco `marketmax` de uma versão anterior deste projeto, **apague o banco** (ou o volume do Docker) antes de subir esta versão, para que o Hibernate recrie o schema e o seed rode corretamente.

---

## Estrutura do Projeto

```
marketmax/
├── backend/
│   ├── src/main/java/com/marketmax/
│   │   ├── config/              # DataInitializer (seed), CorsConfig
│   │   ├── controller/          # REST Controllers (products, categories, cart, orders, users, auth)
│   │   │   └── admin/           # Controllers da área administrativa
│   │   ├── dto/                 # Data Transfer Objects
│   │   │   └── admin/           # DTOs da área administrativa
│   │   ├── exception/           # Tratamento de erros
│   │   ├── model/                # Entidades JPA (inclui Category)
│   │   ├── repository/          # Spring Data JPA Repositories
│   │   ├── security/            # JWT, filtros e configuração do Spring Security
│   │   └── service/              # Lógica de negócios
│   │       └── admin/           # Serviços da área administrativa
│   ├── src/main/resources/
│   │   ├── application.properties
│   │   └── static/              # 👈 FRONTEND (servido pelo Spring Boot)
│   │       ├── index.html       # Home
│   │       ├── produto.html     # Detalhe do produto
│   │       ├── carrinho.html    # Carrinho / checkout
│   │       ├── favoritos.html   # Favoritos
│   │       ├── login.html       # Login
│   │       ├── cadastro.html    # Cadastro de novo usuário
│   │       ├── minha-conta.html # Perfil, senha e pedidos
│   │       ├── admin.html       # Painel administrativo
│   │       ├── css/styles.css
│   │       └── js/
│   │           ├── api.js          # camada de acesso à API (fetch + sessão JWT)
│   │           ├── layout.js       # header/menu/footer compartilhados
│   │           ├── product-card.js # componente de card de produto
│   │           ├── home.js
│   │           ├── produto.js
│   │           ├── carrinho.js
│   │           ├── conta.js
│   │           └── admin.js        # lógica do painel administrativo
│   ├── Dockerfile
│   └── pom.xml
│
├── docker-compose.yml   # mysql + backend (frontend embutido)
├── start.sh
└── README.md
```

---

## Como executar

### Opção 1 — Docker (recomendado)

Pré-requisitos: Docker e Docker Compose instalados.

```bash
./start.sh
# ou diretamente:
docker-compose up --build
```

Acesse:
- **Aplicação**: http://localhost:8080
- **API**: http://localhost:8080/api
- **Swagger UI**: http://localhost:8080/swagger-ui.html

### Opção 2 — Manual (sem Docker)

Pré-requisitos: Java 21, Maven, MySQL 8 rodando localmente.

1. Crie o banco (ou deixe o Hibernate criar automaticamente):
   ```sql
   CREATE DATABASE marketmax CHARACTER SET utf8mb4;
   ```
2. Ajuste usuário/senha em `backend/src/main/resources/application.properties` se necessário (padrão: `root` / `marketmax123`).
3. Rode o backend (que já serve o frontend):
   ```bash
   cd backend
   mvn spring-boot:run
   ```
4. Acesse http://localhost:8080

Na primeira execução, o `DataInitializer` popula o banco com categorias, produtos, imagens, especificações e os dois usuários de demonstração (comprador e administrador — veja a seção Funcionalidades acima).

---

## Autenticação

- Login e cadastro ficam em `/login.html` e `/cadastro.html`.
- Senhas são armazenadas com hash **BCrypt** (nunca em texto puro).
- Ao autenticar, a API retorna um **token JWT** (`/api/auth/login` e `/api/auth/register`), que o frontend guarda no `localStorage` e envia em `Authorization: Bearer <token>` nas chamadas seguintes.
- Rotas de carrinho, favoritos, pedidos, perfil e checkout exigem usuário autenticado; rotas `/api/admin/**` exigem papel `ADMIN`.
- O link **"Minha conta"** no cabeçalho passa a levar para `/minha-conta.html` (ou `/login.html` quando deslogado), e usuários com papel `ADMIN` também veem o link **"Painel Admin"**.

---

## Principais endpoints da API

| Método | Endpoint | Descrição | Acesso |
|---|---|---|---|
| POST | `/api/auth/register` | Cadastrar novo usuário | Público |
| POST | `/api/auth/login` | Autenticar e obter token JWT | Público |
| GET | `/api/auth/me` | Dados do usuário autenticado | Autenticado |
| GET | `/api/products?q=&category=` | Lista produtos (com busca/filtro) | Público |
| GET | `/api/products/{id}` | Detalhe de um produto | Público |
| GET | `/api/products/promotions` | Produtos com desconto ativo | Público |
| GET | `/api/categories` | Categorias com contagem de produtos | Público |
| GET/POST/DELETE | `/api/cart` | Consultar / adicionar / esvaziar carrinho | Autenticado |
| DELETE | `/api/cart/{id}` | Remover item do carrinho | Autenticado |
| POST | `/api/checkout` | Finalizar compra | Autenticado |
| GET | `/api/orders` | Histórico de pedidos do usuário | Autenticado |
| GET/POST | `/api/favorites`, `/api/favorites/toggle` | Listar / alternar favoritos | Autenticado |
| GET/PUT | `/api/profile` | Perfil do usuário | Autenticado |
| POST | `/api/profile/password` | Alterar senha | Autenticado |
| CRUD | `/api/admin/products` | Gerenciar produtos | ADMIN |
| CRUD | `/api/admin/categories` | Gerenciar categorias | ADMIN |
| CRUD | `/api/admin/users` | Gerenciar usuários | ADMIN |
| GET/PUT | `/api/admin/orders`, `/api/admin/orders/{id}/status` | Listar pedidos / atualizar status | ADMIN |
| GET | `/api/admin/stats/*` | Estatísticas para o dashboard (resumo, vendas por dia, top produtos, top usuários, status) | ADMIN |

Documentação interativa completa em `/swagger-ui.html`.
