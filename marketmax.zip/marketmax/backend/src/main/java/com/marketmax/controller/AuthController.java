package com.marketmax.controller;

import com.marketmax.dto.AuthResponse;
import com.marketmax.dto.LoginRequest;
import com.marketmax.dto.RegisterRequest;
import com.marketmax.dto.UserProfileDTO;
import com.marketmax.security.CurrentUserProvider;
import com.marketmax.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Autenticação", description = "Cadastro e login de usuários")
public class AuthController {

    private final AuthService authService;
    private final CurrentUserProvider currentUserProvider;

    @PostMapping("/register")
    @Operation(summary = "Cadastrar novo usuário")
    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }

    @PostMapping("/login")
    @Operation(summary = "Autenticar usuário e obter token JWT")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @GetMapping("/me")
    @Operation(summary = "Obter dados do usuário autenticado a partir do token")
    public ResponseEntity<UserProfileDTO> me() {
        return ResponseEntity.ok(UserProfileDTO.fromEntity(currentUserProvider.getCurrentUser()));
    }
}
