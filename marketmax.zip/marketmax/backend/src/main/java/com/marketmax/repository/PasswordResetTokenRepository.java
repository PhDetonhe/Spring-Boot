package com.marketmax.repository;

import com.marketmax.model.PasswordResetToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Long> {

    Optional<PasswordResetToken> findByToken(String token);

    boolean existsByUserIdAndCreatedAtAfter(Long userId, LocalDateTime createdAt);

    long deleteByExpirationDateBefore(LocalDateTime expirationDate);
}
