package com.marketmax.controller;

import com.marketmax.dto.ForgotPasswordRequest;
import com.marketmax.dto.ResetPasswordRequest;
import com.marketmax.service.PasswordResetService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Recuperação de senha", description = "Solicitação e redefinição de senha")
public class PasswordResetController {

    private static final String FORGOT_PASSWORD_MESSAGE = "Se o email existir, enviaremos instruções de recuperação.";

    private final PasswordResetService passwordResetService;

    @PostMapping("/forgot-password")
    @Operation(summary = "Solicitar recuperação de senha")
    public ResponseEntity<Map<String, String>> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        passwordResetService.requestPasswordReset(request.getEmail());
        return ResponseEntity.ok(Map.of("message", FORGOT_PASSWORD_MESSAGE));
    }

    @PostMapping("/reset-password")
    @Operation(summary = "Redefinir senha com token de recuperação")
    public ResponseEntity<Map<String, Object>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        passwordResetService.resetPassword(request.getToken(), request.getNewPassword());
        return ResponseEntity.ok(Map.of("success", true));
    }
}
