package com.marketmax.service;

import com.marketmax.exception.BusinessException;
import com.marketmax.model.PasswordResetToken;
import com.marketmax.model.User;
import com.marketmax.repository.PasswordResetTokenRepository;
import com.marketmax.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.HexFormat;

@Service
@RequiredArgsConstructor
@Slf4j
public class PasswordResetService {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();
    private static final int TOKEN_BYTES = 32;

    private final UserRepository userRepository;
    private final PasswordResetTokenRepository passwordResetTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;

    @Value("${password.reset.expiration-minutes}")
    private long expirationMinutes;

    @Transactional
    public void requestPasswordReset(String email) {
        User user = userRepository.findByEmail(email.trim().toLowerCase()).orElse(null);
        if (user == null) {
            return;
        }

        LocalDateTime now = LocalDateTime.now();
        if (passwordResetTokenRepository.existsByUserIdAndCreatedAtAfter(user.getId(), now.minusSeconds(60))) {
            return;
        }

        String token = generateToken();
        PasswordResetToken passwordResetToken = PasswordResetToken.builder()
            .user(user)
            .token(token)
            .createdAt(now)
            .expirationDate(now.plusMinutes(expirationMinutes))
            .used(false)
            .build();
        passwordResetTokenRepository.save(passwordResetToken);

        try {
            emailService.sendPasswordResetEmail(user, token, expirationMinutes);
        } catch (Exception ex) {
            // A resposta pública permanece idêntica para não revelar a existência da conta.
            log.warn("Não foi possível enviar o e-mail de recuperação de senha", ex);
        }
    }

    @Transactional
    public void resetPassword(String token, String newPassword) {
        PasswordResetToken passwordResetToken = passwordResetTokenRepository.findByToken(token)
            .orElseThrow(() -> new BusinessException("Token de recuperação inválido ou expirado"));

        LocalDateTime now = LocalDateTime.now();
        if (passwordResetToken.isUsed() || !passwordResetToken.getExpirationDate().isAfter(now)) {
            throw new BusinessException("Token de recuperação inválido ou expirado");
        }

        User user = passwordResetToken.getUser();
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        passwordResetToken.setUsed(true);
        passwordResetToken.setUsedAt(now);

        userRepository.save(user);
        passwordResetTokenRepository.save(passwordResetToken);
    }

    @Scheduled(cron = "0 0 * * * *")
    @Transactional
    public void deleteExpiredTokens() {
        long deletedTokens = passwordResetTokenRepository.deleteByExpirationDateBefore(LocalDateTime.now());
        if (deletedTokens > 0) {
            log.info("{} token(s) de recuperação de senha expirado(s) removido(s)", deletedTokens);
        }
    }

    private String generateToken() {
        byte[] bytes = new byte[TOKEN_BYTES];
        SECURE_RANDOM.nextBytes(bytes);
        return HexFormat.of().formatHex(bytes);
    }
}
