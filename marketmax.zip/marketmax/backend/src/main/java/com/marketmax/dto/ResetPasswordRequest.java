package com.marketmax.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ResetPasswordRequest {

    @NotBlank(message = "O token é obrigatório")
    @Size(max = 128, message = "Token inválido")
    private String token;

    @NotBlank(message = "A nova senha é obrigatória")
    @Size(min = 6, max = 255, message = "A nova senha deve ter entre 6 e 255 caracteres")
    private String newPassword;
}
