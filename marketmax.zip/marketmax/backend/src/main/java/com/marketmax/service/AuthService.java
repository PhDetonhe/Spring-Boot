package com.marketmax.service;

import com.marketmax.dto.AuthResponse;
import com.marketmax.dto.LoginRequest;
import com.marketmax.dto.RegisterRequest;
import com.marketmax.dto.UserProfileDTO;
import com.marketmax.exception.BusinessException;
import com.marketmax.exception.ResourceNotFoundException;
import com.marketmax.model.User;
import com.marketmax.repository.UserRepository;
import com.marketmax.security.AppUserDetails;
import com.marketmax.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (!StringUtils.hasText(request.getName()) ||
            !StringUtils.hasText(request.getEmail()) ||
            !StringUtils.hasText(request.getPassword())) {
            throw new BusinessException("Nome, e-mail e senha são obrigatórios");
        }

        String email = request.getEmail().trim().toLowerCase();

        if (userRepository.existsByEmail(email)) {
            throw new BusinessException("Já existe uma conta cadastrada com este e-mail");
        }

        if (request.getPassword().length() < 6) {
            throw new BusinessException("A senha deve ter pelo menos 6 caracteres");
        }

        User user = User.builder()
            .name(request.getName().trim())
            .email(email)
            .passwordHash(passwordEncoder.encode(request.getPassword()))
            .role("USER")
            .active(true)
            .level("Nível Bronze")
            .memberSince(currentMonthYear())
            .couponsCount(1)
            .coinsCount(0)
            .salesCount(0)
            .build();

        userRepository.save(user);

        String token = jwtService.generateToken(new AppUserDetails(user));
        return new AuthResponse(token, UserProfileDTO.fromEntity(user));
    }

    public AuthResponse login(LoginRequest request) {
        if (!StringUtils.hasText(request.getEmail()) || !StringUtils.hasText(request.getPassword())) {
            throw new BusinessException("E-mail e senha são obrigatórios");
        }

        String email = request.getEmail().trim().toLowerCase();

        try {
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(email, request.getPassword()));
        } catch (org.springframework.security.core.AuthenticationException ex) {
            throw new BusinessException("E-mail ou senha inválidos, ou conta desativada");
        }

        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado"));

        if (!Boolean.TRUE.equals(user.getActive())) {
            throw new BusinessException("Esta conta está desativada. Entre em contato com o suporte.");
        }

        String token = jwtService.generateToken(new AppUserDetails(user));
        return new AuthResponse(token, UserProfileDTO.fromEntity(user));
    }

    private String currentMonthYear() {
        String[] meses = {"Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"};
        java.time.LocalDate now = java.time.LocalDate.now();
        return meses[now.getMonthValue() - 1] + " " + now.getYear();
    }
}
