package com.marketmax.service;

import com.marketmax.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class EmailService {

    private static final String RESET_LINK_BASE = "http://localhost:8080/reset-password?token=";

    @Value("${emailjs.api.url}")
    private String apiUrl;

    @Value("${emailjs.service-id}")
    private String serviceId;

    @Value("${emailjs.template-id}")
    private String templateId;

    @Value("${emailjs.public-key}")
    private String publicKey;

    @Value("${emailjs.private-key}")
    private String privateKey;

    /** Envia exclusivamente o e-mail de recuperação pela API REST do EmailJS. */
    public void sendPasswordResetEmail(User user, String token, long expirationMinutes) {
        Map<String, Object> payload = Map.of(
            "service_id", serviceId,
            "template_id", templateId,
            "user_id", publicKey,
            "accessToken", privateKey,
            "template_params", Map.of(
                "to_email", user.getEmail(),
                "user_name", user.getName(),
                "reset_link", RESET_LINK_BASE + token,
                "expiration_time", expirationMinutes + " minutos"
            )
        );

        RestClient.create()
            .post()
            .uri(apiUrl)
            .contentType(MediaType.APPLICATION_JSON)
            .body(payload)
            .retrieve()
            .toBodilessEntity();
    }
}
