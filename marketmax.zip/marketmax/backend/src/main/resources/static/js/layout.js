/**
 * MarketMax — cabeçalho, menu de categorias e rodapé compartilhados.
 * Renderizados via JS em todas as páginas para evitar duplicar HTML.
 */

function renderHeader() {
  const mount = document.getElementById('site-header');
  if (!mount) return;

  const params = new URLSearchParams(window.location.search);
  const currentQuery = params.get('q') || '';

  mount.innerHTML = `
    <div class="bg-[--ml-yellow] sticky top-0 z-40 shadow-sm">
      <div class="max-w-[1200px] mx-auto px-4 py-2.5 flex items-center gap-4">
        <a href="/index.html" class="flex items-center gap-1.5 shrink-0">
          <span class="text-2xl font-black tracking-tight text-[#2D2D2D]">Market<span class="text-[--ml-blue]">Max</span></span>
        </a>

        <form id="search-form" class="flex-1 flex max-w-2xl">
          <input
            id="search-input"
            type="text"
            value="${escapeHtml(currentQuery)}"
            placeholder="Buscar produtos, marcas e muito mais..."
            class="w-full rounded-l-md px-4 py-2.5 text-sm text-[--ml-text] placeholder-gray-500 border-0 focus:ring-2 focus:ring-[--ml-blue]"
          />
          <button type="submit" aria-label="Buscar" class="bg-white hover:bg-gray-50 px-4 rounded-r-md border-l border-gray-200 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/></svg>
          </button>
        </form>

        <nav class="hidden md:flex items-center gap-4 text-sm text-[#2D2D2D] shrink-0">
          <a href="/favoritos.html" class="hover:underline flex items-center gap-1">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/></svg>
            Favoritos
          </a>
          <span id="admin-link-slot"></span>
          <span id="account-nav-slot"></span>
        </nav>

        <a href="/carrinho.html" class="relative flex items-center shrink-0" aria-label="Carrinho de compras">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-7 h-7 text-[#2D2D2D]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
          </svg>
          <span id="cart-badge" class="hidden absolute -top-2 -right-2 bg-[--ml-blue] text-white text-[11px] font-bold rounded-full w-5 h-5 flex items-center justify-center">0</span>
        </a>
      </div>
    </div>

    <div id="category-nav" class="bg-white border-b border-gray-200 z-30">
      <div class="max-w-[1200px] mx-auto px-4 flex items-center gap-5 overflow-x-auto scrollbar-hide py-2.5 text-sm text-[--ml-text]">
        <a href="/index.html#ofertas" class="whitespace-nowrap font-semibold text-[--ml-red] hover:underline">🔥 Ofertas do dia</a>
        <span id="category-links" class="flex items-center gap-5"></span>
      </div>
    </div>
  `;

  const form = document.getElementById('search-form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const q = document.getElementById('search-input').value.trim();
    window.location.href = `/index.html${q ? `?q=${encodeURIComponent(q)}` : ''}`;
  });

  renderAccountNav();
  refreshCartBadge();
  loadCategoryLinks();
}

/** Renderiza o link "Minha conta" / "Entrar" e o link de Admin conforme a sessão atual */
function renderAccountNav() {
  const slot = document.getElementById('account-nav-slot');
  const adminSlot = document.getElementById('admin-link-slot');
  if (!slot) return;

  if (auth.isLoggedIn()) {
    const user = auth.getUser();
    slot.innerHTML = `
      <div class="relative" id="account-menu-wrapper">
        <button id="account-menu-btn" class="hover:underline flex items-center gap-1">
          ${escapeHtml(user?.name?.split(' ')[0] || 'Minha conta')}
          <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div id="account-menu" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-50">
          <a href="/minha-conta.html" class="block px-4 py-2 text-sm hover:bg-gray-50">Minha conta</a>
          <a href="/carrinho.html" class="block px-4 py-2 text-sm hover:bg-gray-50 md:hidden">Carrinho</a>
          <button id="logout-btn" class="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 text-[--ml-red]">Sair</button>
        </div>
      </div>
    `;
    const btn = document.getElementById('account-menu-btn');
    const menu = document.getElementById('account-menu');
    btn.addEventListener('click', () => menu.classList.toggle('hidden'));
    document.addEventListener('click', (e) => {
      if (!document.getElementById('account-menu-wrapper')?.contains(e.target)) {
        menu.classList.add('hidden');
      }
    });
    document.getElementById('logout-btn').addEventListener('click', () => {
      auth.logout();
      toast('Você saiu da sua conta', 'info');
      window.location.href = '/index.html';
    });

    if (adminSlot && auth.isAdmin()) {
      adminSlot.innerHTML = `<a href="/admin.html" class="hover:underline font-semibold text-[--ml-blue]">Painel Admin</a>`;
    }
  } else {
    slot.innerHTML = `<a href="/login.html" class="hover:underline">Entrar</a>`;
    if (adminSlot) adminSlot.innerHTML = '';
  }
}

async function loadCategoryLinks() {
  const mount = document.getElementById('category-links');
  if (!mount) return;
  try {
    const categories = await api.categories.list();
    mount.innerHTML = categories.map(c => `
      <a href="/index.html?category=${encodeURIComponent(c.id)}" class="whitespace-nowrap hover:text-[--ml-blue] hover:underline">
        ${c.icon} ${escapeHtml(c.name)}
      </a>
    `).join('');
  } catch (e) {
    console.error('Falha ao carregar categorias', e);
  }
}

function renderFooter() {
  const mount = document.getElementById('site-footer');
  if (!mount) return;
  mount.innerHTML = `
    <footer class="bg-white border-t border-gray-200 mt-12">
      <div class="max-w-[1200px] mx-auto px-4 py-10 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div>
          <h4 class="font-bold mb-3 text-[--ml-text]">Sobre o MarketMax</h4>
          <ul class="space-y-2 text-[--ml-text-light]">
            <li>Quem somos</li>
            <li>Trabalhe conosco</li>
            <li>Termos e condições</li>
          </ul>
        </div>
        <div>
          <h4 class="font-bold mb-3 text-[--ml-text]">Ajuda</h4>
          <ul class="space-y-2 text-[--ml-text-light]">
            <li>Comprar no MarketMax</li>
            <li>Como vender</li>
            <li>Central de segurança</li>
          </ul>
        </div>
        <div>
          <h4 class="font-bold mb-3 text-[--ml-text]">Formas de pagamento</h4>
          <ul class="space-y-2 text-[--ml-text-light]">
            <li>Cartões de crédito</li>
            <li>Pix</li>
            <li>Boleto</li>
          </ul>
        </div>
        <div>
          <h4 class="font-bold mb-3 text-[--ml-text]">MarketMax</h4>
          <p class="text-[--ml-text-light]">Projeto de demonstração: Spring Boot + MySQL + HTML/JS + Tailwind.</p>
        </div>
      </div>
      <div class="border-t border-gray-100 py-4 text-center text-xs text-[--ml-text-light]">
        © ${new Date().getFullYear()} MarketMax — projeto de estudo inspirado no Mercado Livre.
      </div>
    </footer>
  `;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

document.addEventListener('DOMContentLoaded', () => {
  renderHeader();
  renderFooter();
});
